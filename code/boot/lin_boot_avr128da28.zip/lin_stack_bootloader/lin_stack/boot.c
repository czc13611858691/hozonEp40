/*
 * boot.c
 *
 * Created: 2021/11/2 11:09:28
 *  Author: JasonZhu
 */ 
#include <atmel_start.h>
#include "lin_driver.h"
#include "lin1.h"
#include "lin_common_api.h"
#include "app_config.h"


