#include <atmel_start.h>
#include "./usr/hc595d/hc595.h"
#include "lin1.h"
#include "lin_common_api.h"
#include "app_config.h"
#include "lin_commontl_api.h"
#include "./usr/os_t/soft_timer.h"
#include "rstctrl.h"
#include "ep40_function_specification.h"

uint8_t eeprom_set_boot_flg = 0;
int erase_flag = 0;
int flash_flag = 0;
int jump_flag = 0;
uint16_t rb;

uint8_t program_buffer[512] = {0};
uint8_t history_blcok_count;
uint16_t update_cnt = 0;
int bin_size_cnt = 0;
;
//flash_adr_t page_addr = 0x4800;
uint32_t page_addr = 0x4800;
uint8_t ok;

uint8_t led_data[2] = {0x00,0x00};
int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	l_sys_init();
	l_ifc_init(LI0);
	ld_init(LI0);
	Enable_global_interrupt();

	/* Replace with your application code */

	// test PWM IO control 
	// BAT_CTR1_set_level(1);
	// BAT_CTR2_set_level(1);
	// TCA0.SPLIT.HCMP1 = 29;
	TCA0.SPLIT.LCMP2 = 20;
	
	// test led backlight
	HC595_Write(led_data,2,16);
	//HC595_Write(led_data,1,8);
	soft_timer_create(20, btn_process_task);
	soft_timer_create(10, ep40_integrate_all_signal);
	soft_timer_create(100,backlight_task);
	while (1) {
		soft_timer_run();
		touch_process();
		if (eeprom_set_boot_flg == 1)
		{
			eeprom_set_boot_flg = 0;
			FLASH_0_write_eeprom_byte(0x00, 0xaa);
			while (NVMCTRL.STATUS & (NVMCTRL_EEBUSY_bm | NVMCTRL_FBUSY_bm))
				;
			RSTCTRL_reset();
		}
	}
}
